//Marghretta Pizza.
var margSize=document.getElementById("size");
var quantity=document.getElementById("qty");
var margPrice=document.getElementById("margPrice");

margSize.addEventListener("change",function(){
var size=margSize.value;
var qty=quantity.value;
     if(qty=="one" && size=="small"){
        margPrice.innerHTML=210;
     }
    else if(qty=="two" && size=="small"){
        margPrice.innerHTML=420;
     }
     else if(qty=="three" && size=="small"){
        margPrice.innerHTML=630;
     }
     else if(qty=="four" && size=="small"){
        margPrice.innerHTML=840;
     }

     else if(qty=="five" && size=="small"){
        margPrice.innerHTML=1050;
     }
    else if(qty=="one" && size=="medium"){
        margPrice.innerHTML=349;
     }

     else if(qty=="two" && size=="medium"){
        margPrice.innerHTML=700;
     }

     else if(qty=="three" && size=="medium"){
        margPrice.innerHTML=1050;
     }

     else if(qty=="four" && size=="medium"){
        margPrice.innerHTML=1400;
     }

     else if(qty=="five" && size=="medium"){
        margPrice.innerHTML=1750;
     }

     else if(qty=="one" && size=="large")
     {
        margPrice.innerHTML=399;
     }
     else if(qty=="two" && size=="large"){
        margPrice.innerHTML=800;
     }

     else if(qty=="three" && size=="large"){
        margPrice.innerHTML=1200;
     }

     else if(qty=="four" && size=="large"){
        margPrice.innerHTML=1600;
     }

     else if(qty=="five" && size=="large"){
        margPrice.innerHTML=2000;
}
})



// Tossing Pizza
var tossingSize=document.getElementById("tSize");

var tossingPrice=document.getElementById("tossingPrice");

var tossingQuantity=document.getElementById("tossingQty")
tossingSize.addEventListener("change",function(){
var qty=tossingQuantity.value;

    var size=tossingSize.value;
    if( qty=="one" && size=="small"){
        tossingPrice.innerHTML=229;
    }

    else if( qty=="two" && size=="small"){
        tossingPrice.innerHTML=460;
    }

    else if( qty=="three" && size=="small"){
        tossingPrice.innerHTML=690;
    }

    else if( qty=="four" && size=="small"){
        tossingPrice.innerHTML=920;
    }

    else if( qty=="five" && size=="small"){
        tossingPrice.innerHTML=1150;
    }

    else if(qty=="one" && size=="medium"){
        tossingPrice.innerHTML=350;
    }

    else if( qty=="two" && size=="medium"){
        tossingPrice.innerHTML=700;
    }

    else if( qty=="three" && size=="medium"){
        tossingPrice.innerHTML=1050;
    }

    else if( qty=="four" && size=="medium"){
        tossingPrice.innerHTML=1400;
    }

    else if( qty=="five" && size=="medium"){
        tossingPrice.innerHTML=1600;
    }


    else if(qty=="one" && size=="large"){
        tossingPrice.innerHTML=400;
    }
    else if( qty=="two" && size=="large"){
        tossingPrice.innerHTML=800;
    }

    else if( qty=="three" && size=="large"){
        tossingPrice.innerHTML=1200;
    }

    else if( qty=="four" && size=="large"){
        tossingPrice.innerHTML=1600;
    }

    else if( qty=="five" && size=="large"){
        tossingPrice.innerHTML=2000;
    }
})


//pepp pizza
var pepSize=document.getElementById("pSize");

var pepPrice=document.getElementById("pepPrice");

var pepQuantity=document.getElementById("pepQty")

pepSize.addEventListener("change",function(){
    var size=pepSize.value;
    var qty=pepQuantity.value;

    if(qty=="one" && size=="small"){
        pepPrice.innerHTML=260;
    }
    else if(qty=="two" && size=="small"){
        pepPrice.innerHTML=500;
    }
    else if(qty=="three" && size=="small"){
        pepPrice.innerHTML=780;
    }
    else if(qty=="four" && size=="small"){
        pepPrice.innerHTML=1040;
    }
    else if(qty=="five" && size=="small"){
        pepPrice.innerHTML=1300;
    }
    else if(qty=="one"&&size=="medium"){
        pepPrice.innerText=319;
    }
    else if(qty=="two" && size=="medium"){
        pepPrice.innerHTML=640;
    }
    else if(qty=="three" && size=="medium"){
        pepPrice.innerHTML=960;
    }
    else if(qty=="four" && size=="medium"){
        pepPrice.innerHTML=1280;
    }
    else if(qty=="five" && size=="medium"){
        pepPrice.innerHTML=1600;
    }
    else if(qty=="one"&&size=="large"){
        pepPrice.innerText=399;
    }
    else if(qty=="two" && size=="large"){
        pepPrice.innerHTML=700;
    }
    else if(qty=="three" && size=="large"){
        pepPrice.innerHTML=1000;
    }
    else if(qty=="four" && size=="large"){
        pepPrice.innerHTML=1300;
    }
    else if(qty=="five" && size=="large"){
        pepPrice.innerHTML=1800;
    }
})

//peppy paneer pizza
var peppySize=document.getElementById("peppySize");

var peppyPrice=document.getElementById("peppyPrice");

var peppyQuantity=document.getElementById("peppyQty");

peppySize.addEventListener("change",function(){
    var size=peppySize.value;
    var qty=peppyQuantity.value;

    if(qty=="one" && size=="small"){
        peppyPrice.innerHTML=189;
    }
    else if(qty=="two" && size=="small"){
        peppyPrice.innerHTML=299;
    }
    else if(qty=="three" && size=="small"){
        peppyPrice.innerHTML=499;
    }
    else if(qty=="four" && size=="small"){
        peppyPrice.innerHTML=699;
    }
    else if(qty=="five" && size=="small"){
        peppyPrice.innerHTML=749;
    }
    else if(qty=="one"&&size=="medium"){
        peppyPrice.innerHTML=249;
    }
    else if(qty=="two" && size=="medium"){
        peppyPrice.innerHTML=500;
    }
    else if(qty=="three" && size=="medium"){
        peppyPrice.innerHTML=650;
    }
    else if(qty=="four" && size=="medium"){
        peppyPrice.innerHTML=800;
    }
    else if(qty=="five" && size=="medium"){
        peppyPrice.innerHTML=999;
    }
    else if(qty=="one" && size=="large"){
        peppyPrice.innerHTML=299;
    }
    else if(qty=="two" && size=="large"){
        peppyPrice.innerHTML=600;
    }
    else if(qty=="three" && size=="large"){
        peppyPrice.innerHTML=850;
    }
    else if(qty=="four" && size=="large"){
        peppyPrice.innerHTML=1050;
    }
    else if(qty=="five" && size=="large"){
        peppyPrice.innerHTML=1250;
    }
})




//Aussie pizza
var aussieSize=document.getElementById("aussieSize");

var aussiePrice=document.getElementById("aussiePrice");
 var aussieQuantity=document.getElementById("aussieQty");

aussieSize.addEventListener("change",function(){
    var size=aussieSize.value;
    var qty=aussieQuantity.value;

    if(qty=="one" &&size=="small"){
        aussiePrice.innerHTML=279;
    }
    else if(qty=="two" && size=="small"){
       aussiePrice.innerHTML=399;
    }
    else if(qty=="three" && size=="small"){
       aussiePrice.innerHTML=449;
    }
    else if(qty=="four" && size=="small"){
       aussiePrice.innerHTML=649;
    }
    else if(qty=="five" && size=="small"){
       aussiePrice.innerHTML=750;
    }
    else if(qty=="one" && size=="medium"){
        aussiePrice.innerHTML=299;
    }
    else if(qty=="two" && size=="medium"){
        aussiePrice.innerHTML=599;
     }
     else if(qty=="three" && size=="medium"){
        aussiePrice.innerHTML=849;
     }
     else if(qty=="four" && size=="medium"){
        aussiePrice.innerHTML=1049;
     }
     else if(qty=="five" && size=="medium"){
        aussiePrice.innerHTML=1399;
     }
     else if(qty=="one" && size=="large"){
        aussiePrice.innerHTML=379;
    }
    else if(qty=="two" && size=="large"){
        aussiePrice.innerHTML=699;
     }
     else if(qty=="three" && size=="large"){
        aussiePrice.innerHTML=1080;
     }
     else if(qty=="four" && size=="large"){
        aussiePrice.innerHTML=1460;
     }
     else if(qty=="five" && size=="large"){
        aussiePrice.innerHTML=1740;
     }
})

//Cheese N corn Pizza
var cncSize=document.getElementById("cncSize");

var cncPrice=document.getElementById("cncPrice");

var cncQuantity=document.getElementById("cncQty")
cncSize.addEventListener("change",function(){
    var size=cncSize.value;
    var qty=cncQuantity.value;

    if(qty=="one"&&size=="small"){
        cncPrice.innerHTML=249;
    }
    else if(qty=="two" && size=="small"){
        cncPrice.innerHTML=499;
     }
     else if(qty=="three" && size=="small"){
        cncPrice.innerHTML=750;
     }
     else if(qty=="four" && size=="small"){
        cncPrice.innerHTML=850;
     }
     else if(qty=="five" && size=="small"){
        cncPrice.innerHTML=999;
     }
      else if(qty=="one" &&size=="medium"){
        cncPrice.innerHTML=320;
    }
    else if(qty=="two" && size=="medium"){
        cncPrice.innerHTML=640;
     }
     else if(qty=="three" && size=="medium"){
        cncPrice.innerHTML=860;
     }
     else if(qty=="four" && size=="medium"){
        cncPrice.innerHTML=1100;
     }
     else if(qty=="five" && size=="medium"){
        cncPrice.innerHTML=1400;
     }
     else if(qty=="one" && size=="large"){
        cncPrice.innerHTML=349;
    }
    else if(qty=="two" && size=="large"){
        cncPrice.innerHTML=699;
     }
     else if(qty=="three" && size=="large"){
        cncPrice.innerHTML=1050;
     }
     else if(qty=="four" && size=="large"){
        cncPrice.innerHTML=1400;
     }
     else if(qty=="five" && size=="large"){
        cncPrice.innerHTML=1699;
     }
})

//Spring pizza.
var springSize=document.getElementById("springSize");

var springPrice=document.getElementById("springPrice");

var springQuantity=document.getElementById("springQty")
springSize.addEventListener("change",function(){
    var size=springSize.value;
    var qty=springQuantity.value;

    if(qty=="one"&&size=="small"){
        springPrice.innerHTML=200;
    }
    else if(qty=="two" && size=="small"){
        springPrice.innerHTML=400;
     }
     else if(qty=="three" && size=="small"){
        springPrice.innerHTML=600;
     }
     else if(qty=="four" && size=="small"){
        springPrice.innerHTML=800;
     }
     else if(qty=="five" && size=="small"){
        springPrice.innerHTML=999;
     }
     else if(qty=="one" &&size=="medium"){
        springPrice.innerHTML=250;
    }
    else if(qty=="two" && size=="medium"){
        springPrice.innerHTML=500;
     }
     else if(qty=="three" && size=="medium"){
        springPrice.innerHTML=750;
     }
     else if(qty=="four" && size=="medium"){
        springPrice.innerHTML=1000;
     }
     else if(qty=="five" && size=="medium"){
        springPrice.innerHTML=1200;
     }
     else if(qty=="one" && size=="large"){
        springPrice.innerHTML=300;
    }
    else if(qty=="two" && size=="large"){
        springPrice.innerHTML=600;
     }
     else if(qty=="three" && size=="large"){
        springPrice.innerHTML=900;
     }
     else if(qty=="four" && size=="large"){
        springPrice.innerHTML=1100;
     }
     else if(qty=="five" && size=="large"){
        springPrice.innerHTML=1399;
     }
})

//Hawaiiyan Pizza
var hawaiiyanSize=document.getElementById("hawaiiyanSize");

var hawaiiyanPrice=document.getElementById("hawaiiyanPrice");

var hawaiiyanQuantity=document.getElementById("hawaiiyanQty")
hawaiiyanSize.addEventListener("change",function(){
    var size=hawaiiyanSize.value;
    var qty=hawaiiyanQuantity.value;

    if(qty=="one"&&size=="small"){
        hawaiiyanPrice.innerHTML=159;
    }
    else if(qty=="two" && size=="small"){
        hawaiiyanPrice.innerHTML=320;
     }
     else if(qty=="three" && size=="small"){
        hawaiiyanPrice.innerHTML=480;
     }
     else if(qty=="four" && size=="small"){
        hawaiiyanPrice.innerHTML=600;
     }
     else if(qty=="five" && size=="small"){
        hawaiiyanPrice.innerHTML=750;
     }
     else if(qty=="one" &&size=="medium"){
        hawaiiyanPrice.innerHTML=200;
    }
    else if(qty=="two" && size=="medium"){
        hawaiiyanPrice.innerHTML=400;
     }
     else if(qty=="three" && size=="medium"){
        hawaiiyanPrice.innerHTML=600;
     }
     else if(qty=="four" && size=="medium"){
        hawaiiyanPrice.innerHTML=800;
     }
     else if(qty=="five" && size=="medium"){
        hawaiiyanPrice.innerHTML=999;
     }
     else if(qty=="one" && size=="large"){
        hawaiiyanPrice.innerHTML=350;
    }
    else if(qty=="two" && size=="large"){
        hawaiiyanPrice.innerHTML=750;
     }
     else if(qty=="three" && size=="large"){
        hawaiiyanPrice.innerHTML=1050;
     }
     else if(qty=="four" && size=="large"){
        hawaiiyanPrice.innerHTML=1399;
     }
     else if(qty=="five" && size=="large"){
        hawaiiyanPrice.innerHTML=1699;
     }
})

//cappricciosa Pizza.
var cappricciosaSize=document.getElementById("cappricciosaSize");

var cappricciosaPrice=document.getElementById("cappricciosaPrice");

var cappricciosaQuantity=document.getElementById("cappricciosaQty");

cappricciosaSize.addEventListener("change",function(){
    var size=cappricciosaSize.value;
    var qty=cappricciosaQuantity.value;

    if(qty=="one"&&size=="small"){
        cappricciosaPrice.innerHTML=149;
    }
    else if(qty=="two" && size=="small"){
        cappricciosaPrice.innerHTML=300;
     }
     else if(qty=="three" && size=="small"){
        cappricciosaPrice.innerHTML=450;
     }
     else if(qty=="four" && size=="small"){
        cappricciosaPrice.innerHTML=600;
     }
     else if(qty=="five" && size=="small"){
        cappricciosaPrice.innerHTML=700;
     }
     else if(qty=="one" &&size=="medium"){
        cappricciosaPrice.innerHTML=250;
    }
    else if(qty=="two" && size=="medium"){
        cappricciosaPrice.innerHTML=450;
     }
     else if(qty=="three" && size=="medium"){
        cappricciosaPrice.innerHTML=550;
     }
     else if(qty=="four" && size=="medium"){
        cappricciosaPrice.innerHTML=700;
     }
     else if(qty=="five" && size=="medium"){
        cappricciosaPrice.innerHTML=850;
     }
     else if(qty=="one" && size=="large"){
        cappricciosaPrice.innerHTML=400;
    }
    else if(qty=="two" && size=="large"){
        cappricciosaPrice.innerHTML=800;
     }
     else if(qty=="three" && size=="large"){
        cappricciosaPrice.innerHTML=1200;
     }
     else if(qty=="four" && size=="large"){
        cappricciosaPrice.innerHTML=1499;
     }
     else if(qty=="five" && size=="large"){
        cappricciosaPrice.innerHTML=1899;
     }
})

//Deluxe pizza.
var deluxeSize=document.getElementById("deluxeSize");

var deluxePrice=document.getElementById("deluxePrice");

var deluxeQuantity=document.getElementById("deluxeQty");

deluxeSize.addEventListener("change",function(){
    var size=deluxeSize.value;
    var qty=deluxeQuantity.value;

    if(qty=="one"&&size=="small"){
        deluxePrice.innerHTML=120;
    }
    else if(qty=="two" && size=="small"){
        deluxePrice.innerHTML=240;
     }
     else if(qty=="three" && size=="small"){
        deluxePrice.innerHTML=360;
     }
     else if(qty=="four" && size=="small"){
        deluxePrice.innerHTML=480;
     }
     else if(qty=="five" && size=="small"){
        deluxePrice.innerHTML=600;
     }
     else if(qty=="one" &&size=="medium"){
        deluxePrice.innerHTML=150;
    }
    else if(qty=="two" && size=="medium"){
        deluxePrice.innerHTML=300;
     }
     else if(qty=="three" && size=="medium"){
        deluxePrice.innerHTML=450;
     }
     else if(qty=="four" && size=="medium"){
        deluxePrice.innerHTML=600;
     }
     else if(qty=="five" && size=="medium"){
        deluxePrice.innerHTML=700;
     }
     else if(qty=="one" && size=="large"){
        deluxePrice.innerHTML=200;
    }
    else if(qty=="two" && size=="large"){
        deluxePrice.innerHTML=400;
     }
     else if(qty=="three" && size=="large"){
        deluxePrice.innerHTML=600;
     }
     else if(qty=="four" && size=="large"){
        deluxePrice.innerHTML=800;
     }
     else if(qty=="five" && size=="large"){
        deluxePrice.innerHTML=999;
     }
})

//MNC pizza.

var mncSize=document.getElementById("mncSize");

var mncPrice=document.getElementById("mncPrice");

var mncQuantity=document.getElementById("mncQty");

mncSize.addEventListener("change",function(){
    var size=mncSize.value;
    var qty=mncQuantity.value;

    if(qty=="one"&&size=="small"){
        mncPrice.innerHTML=349;
    }
    else if(qty=="two" && size=="small"){
        mncPrice.innerHTML=399;
     }
     else if(qty=="three" && size=="small"){
        mncPrice.innerHTML=440;
     }
     else if(qty=="four" && size=="small"){
        mncPrice.innerHTML=480;
     }
     else if(qty=="five" && size=="small"){
        mncPrice.innerHTML=500;
     }
     else if(qty=="one" &&size=="medium"){
        mncPrice.innerHTML=180;
    }
    else if(qty=="two" && size=="medium"){
        mncPrice.innerHTML=360;
     }
     else if(qty=="three" && size=="medium"){
        mncPrice.innerHTML=540;
     }
     else if(qty=="four" && size=="medium"){
        mncPrice.innerHTML=720;
     }
     else if(qty=="five" && size=="medium"){
        mncPrice.innerHTML=900;
     }
     else if(qty=="one" && size=="large"){
        mncPrice.innerHTML=250;
    }
    else if(qty=="two" && size=="large"){
        mncPrice.innerHTML=500;
     }
     else if(qty=="three" && size=="large"){
        mncPrice.innerHTML=730;
     }
     else if(qty=="four" && size=="large"){
        mncPrice.innerHTML=890;
     }
     else if(qty=="five" && size=="large"){
        mncPrice.innerHTML=1100;
     }
})

//Grilled Pizza
var grillSize=document.getElementById("grillSize");

var grillPrice=document.getElementById("grillPrice");

var grillQuantity=document.getElementById("grillQty");

grillSize.addEventListener("change",function(){
    var size=grillSize.value;
    var qty=grillQuantity.value;

    if(qty=="one"&&size=="small"){
        grillPrice.innerHTML=299;
    }
    else if(qty=="two" && size=="small"){
        grillPrice.innerHTML=500;
     }
     else if(qty=="three" && size=="small"){
        grillPrice.innerHTML=650;
     }
     else if(qty=="four" && size=="small"){
        grillPrice.innerHTML=720;
     }
     else if(qty=="five" && size=="small"){
        grillPrice.innerHTML=800;
     }
     else if(qty=="one" &&size=="medium"){
        grillPrice.innerHTML=350;
    }
    else if(qty=="two" && size=="medium"){
        grillPrice.innerHTML=650;
     }
     else if(qty=="three" && size=="medium"){
        grillPrice.innerHTML=800;
     }
     else if(qty=="four" && size=="medium"){
        grillPrice.innerHTML=950;
     }
     else if(qty=="five" && size=="medium"){
        grillPrice.innerHTML=1070;
     }
     else if(qty=="one" && size=="large"){
        grillPrice.innerHTML=380;
    }
    else if(qty=="two" && size=="large"){
        grillPrice.innerHTML=760;
     }
     else if(qty=="three" && size=="large"){
        grillPrice.innerHTML=999;
     }
     else if(qty=="four" && size=="large"){
        grillPrice.innerHTML=1299;
     }
     else if(qty=="five" && size=="large"){
        grillPrice.innerHTML=1500;
     }
})

//Coke Combo
var cokeSize=document.getElementById("cokeSize");

var cokePrice=document.getElementById("cokePrice");

var cokeQuantity=document.getElementById("cokeQty");

cokeSize.addEventListener("change",function(){
    var size=cokeSize.value;
    var qty=cokeQuantity.value;

    if(qty=="one"&&size=="small"){
        cokePrice.innerHTML=449;
    }
    else if(qty=="two" && size=="small"){
        cokePrice.innerHTML=699;
     }
     else if(qty=="three" && size=="small"){
        cokePrice.innerHTML=999;
     }
     else if(qty=="four" && size=="small"){
        cokePrice.innerHTML=1099;
     }
     else if(qty=="five" && size=="small"){
        cokePrice.innerHTML=1199;
     }
     else if(qty=="one" &&size=="medium"){
        cokePrice.innerHTML=550;
    }
    else if(qty=="two" && size=="medium"){
        cokePrice.innerHTML=799;
     }
     else if(qty=="three" && size=="medium"){
        cokePrice.innerHTML=999;
     }
     else if(qty=="four" && size=="medium"){
        cokePrice.innerHTML=1199;
     }
     else if(qty=="five" && size=="medium"){
        cokePrice.innerHTML=1299;
     }
     else if(qty=="one" && size=="large"){
        cokePrice.innerHTML=600;
    }
    else if(qty=="two" && size=="large"){
        cokePrice.innerHTML=1100;
     }
     else if(qty=="three" && size=="large"){
        cokePrice.innerHTML=1700;
     }
     else if(qty=="four" && size=="large"){
        cokePrice.innerHTML=1900;
     }
     else if(qty=="five" && size=="large"){
        cokePrice.innerHTML=2000;
     }
})

//Pepsi pizza

var pepsiSize=document.getElementById("pepsiSize");

var pepsiPrice=document.getElementById("pepsiPrice");

var pepsiQuantity=document.getElementById("pepsiQty");

pepsiSize.addEventListener("change",function(){
    var size=pepsiSize.value;
    var qty=pepsiQuantity.value;

    if(qty=="one"&&size=="small"){
        pepsiPrice.innerHTML=499;
    }
    else if(qty=="two" && size=="small"){
        pepsiPrice.innerHTML=699;
     }
     else if(qty=="three" && size=="small"){
        pepsiPrice.innerHTML=899;
     }
     else if(qty=="four" && size=="small"){
        pepsiPrice.innerHTML=999;
     }
     else if(qty=="five" && size=="small"){
        pepsiPrice.innerHTML=1099;
     }
     else if(qty=="one" &&size=="medium"){
        pepsiPrice.innerHTML=530;
    }
    else if(qty=="two" && size=="medium"){
        pepsiPrice.innerHTML=749;
     }
     else if(qty=="three" && size=="medium"){
        pepsiPrice.innerHTML=990;
     }
     else if(qty=="four" && size=="medium"){
        pepsiPrice.innerHTML=1109;
     }
     else if(qty=="five" && size=="medium"){
        pepsiPrice.innerHTML=1199;
     }
     else if(qty=="one" && size=="large"){
        pepsiPrice.innerHTML=560;
    }
    else if(qty=="two" && size=="large"){
        pepsiPrice.innerHTML=770;
     }
     else if(qty=="three" && size=="large"){
        pepsiPrice.innerHTML=990;
     }
     else if(qty=="four" && size=="large"){
        pepsiPrice.innerHTML=1200;
     }
     else if(qty=="five" && size=="large"){
        pepsiPrice.innerHTML=1300;
     }
})

//Fries combo.

var friesSize=document.getElementById("friesSize");

var friesPrice=document.getElementById("friesPrice");

var friesQuantity=document.getElementById("friesQty");

friesSize.addEventListener("change",function(){
    var size=friesSize.value;
    var qty=friesQuantity.value;

    if(qty=="one"&&size=="small"){
        friesPrice.innerHTML=599;
    }
    else if(qty=="two" && size=="small"){
        friesPrice.innerHTML=699;
     }
     else if(qty=="three" && size=="small"){
        friesPrice.innerHTML=799;
     }
     else if(qty=="four" && size=="small"){
        friesPrice.innerHTML=899;
     }
     else if(qty=="five" && size=="small"){
        friesPrice.innerHTML=999;
     }
     else if(qty=="one" &&size=="medium"){
        friesPrice.innerHTML=650;
    }
    else if(qty=="two" && size=="medium"){
        friesPrice.innerHTML=749;
     }
     else if(qty=="three" && size=="medium"){
        friesPrice.innerHTML=950;
     }
     else if(qty=="four" && size=="medium"){
        friesPrice.innerHTML=1150;
     }
     else if(qty=="five" && size=="medium"){
        friesPrice.innerHTML=1299;
     }
     else if(qty=="one" && size=="large"){
        friesPrice.innerHTML=700;
    }
    else if(qty=="two" && size=="large"){
        friesPrice.innerHTML=970;
     }
     else if(qty=="three" && size=="large"){
        friesPrice.innerHTML=1100;
     }
     else if(qty=="four" && size=="large"){
        friesPrice.innerHTML=1300;
     }
     else if(qty=="five" && size=="large"){
        friesPrice.innerHTML=1400;
     }
})

//Sprite combo.

var spriteSize=document.getElementById("spriteSize");

var spritePrice=document.getElementById("spritePrice");

var spriteQuantity=document.getElementById("spriteQty");

spriteSize.addEventListener("change",function(){
    var size=spriteSize.value;
    var qty=spriteQuantity.value;
    if(qty=="one"&&size=="small"){
        spritePrice.innerHTML=699;
    }
    else if(qty=="two" && size=="small"){
        spritePrice.innerHTML=999;
     }
    else if(qty=="one" &&size=="medium"){
        spritePrice.innerHTML=1199;
    }
    else if(qty=="two" && size=="medium"){
        spritePrice.innerHTML=1449;
     }
     else if(qty=="one" && size=="large"){
        spritePrice.innerHTML=1499;
    }
    else if(qty=="two" && size=="large"){
        spritePrice.innerHTML=1999;
     }
})






























