const express=require('express');
const session = require('express-session');
const bodyParser=require('body-parser');
const mongoose=require('mongoose')
const app=express();
app.use(bodyParser.json());
app.use(session({
  secret: 'mySecret',
  resave: false,
  saveUninitialized: false,
}));
app.use(express.static(__dirname));

mongoose.connect('mongodb://127.0.0.1:27017/restaurantDb')

const orderSchema = new mongoose.Schema({
    name:{
      type: String,
    },
    size:{
      type: String,
      required: true
    },
    qty:{
      type: String,
      required: true
    },
    user:{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    }
  });
  const Order = mongoose.model('Order', orderSchema);

  const userSchema=new mongoose.Schema({
    fullName:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true,
    },
    password:{
        type:String,
        required:true
    },
    mobile:{
        type:Number,
        required:true,
        minlenght:10,
        maxlength:10
    },
    city:{
        type:String,
        required:true,
    },
    pinCode:{
        type:String,
        required:true,
    },
    address:{
        type:String,
        required:true
    }
})

const User=mongoose.model('User',userSchema);

app.use(bodyParser.urlencoded({extended:true}))

app.post('/signup',function(req,res){
    const { fullName, email, password, mobile, city, pinCode, address } = req.body;

    User.findOne({ email }).then(existingUser => {
      if (existingUser) {
        res.status(409).send('User with the same email already exists');
      } else {
        const user = new User({ fullName, email, password, mobile, city, pinCode, address });
        user.save()
          .then(() => {
             res.send('<h1>Registration Successful!</h1><br>  <p>Click <a href="login.html">here</a> for Login</p> <style>h1{text-align:center} p{text-align:center; font-weight:bolder;font-size:larger;} a{color:red;}');
          })
          .catch((error) => {
            res.status(500).send('Error saving information');
          });
      }
    }).catch((error) => {
      res.status(500).send('Internal server error');
    });
  });

  app.post('/login',function(req,res){
    const { email, password } = req.body;
    User.findOne({ email, password }).then(function(user) {
      if (user) {
        req.session.userId = user._id;
        res.redirect('/menu.html');
      } else {
        res.status(401).send('Invalid login details');
      }
    })
    .catch(function(error){
      res.status(500).send('Internal server error');
    });
  });

app.post('/order', (req, res) => {
    const { name, size, qty } = req.body;
    const userId = req.session.userId;
    if (!userId) {
      res.status(401).send('You need to be logged in to place an order');
    } else {
      const newOrder = new Order({name,size, qty, user: userId });
      newOrder.save()
        .then(() => {
          res.status(201).send('<h1>Order placed successfully!</h1> <style>h1{text-align:center} img{height:70%; width:100%; margin-top:3%}</style><br> <img src="thankyou.png">  ');
        })
        .catch((err) => {
          console.error(`Error saving order to database: ${err.message}`);
          res.status(500).send('Internal server error');
        });
    }
  });


  app.post('/admin', (req, res) => {
    const { username, password } = req.body;
    if (username === 'admin' && password === 'admin') {
      User.find({}).then(function(users) {
        Order.find({}).then(function(orders) {
         res.send(` <h3>Users = ${users} </h3> <hr> <h3>Orders = ${orders}</h3>`)
        });
      });
    }
  });

   //Middleware to check if the user is authenticated
  const authMiddleware = (req, res, next) => {
    if (!req.session.userId) {
      res.redirect('/login.html');
    } else {
      next();
    }
  };
 // Menu page accessible only to authenticated users
  app.get('/menu.html', authMiddleware, (req, res) => {
    res.sendFile(__dirname+'/menu.html');
  });

app.get('/',function(req,res){
  res.sendFile(__dirname+'/index.html')
})

app.listen('3000',function(){
    console.log('server started at port 3000')
});


















